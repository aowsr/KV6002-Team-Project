<?php

require_once('classes/webpage.class.php');
require_once('errorFunctions.php');
require_once('setEnv.php');
require_once('setPath.php');
require_once('classes/pdoDB.class.php');
require_once('classes/ApplicationRegistry.class.php');
require_once('classes/JSONRecordSet.class.php');
require_once('classes/session.class.php');


session_start();

$db = ApplicationRegistry::DB(); // connect to db

$form_data = json_decode(file_get_contents("php://input"));

$validation_error = '';

if (empty($form_data->email)) {
    $error[] = 'Email is Required';
} else {
    if (!filter_var($form_data->email, FILTER_VALIDATE_EMAIL)) {
        $error[] = 'Invalid Email Format';
    } else {
        $data[':email'] = $form_data->email;
    }
}

if (empty($form_data->password)) {
    $error[] = 'Password is Required';
}

if (empty($error)) {
    $query = "SELECT * FROM nfc_user 
              WHERE email = :email";

    $statement = $db->prepare($query);
    if ($statement->execute($data)) {
        $result = $statement->fetchAll();
        if ($statement->rowCount() > 0)
        {
            foreach ($result as $row) {
                if (password_verify($form_data->password, $row["password"])) {
                    $_SESSION["name"] = $row["name"];
                } else {
                    $validation_error = 'Wrong Password';
                }
            }
        } else {
            $validation_error = 'Wrong Email';
        }
    }
} else {
    $validation_error = implode(", ", $error);
}

$output = array(
    'error' => $validation_error
);

echo json_encode($output);

?>
