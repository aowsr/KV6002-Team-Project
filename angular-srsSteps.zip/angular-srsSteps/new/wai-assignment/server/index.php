<?php
require_once('classes/webpage.class.php');
require_once('errorFunctions.php');
require_once('setEnv.php');
require_once('setPath.php');
require_once('classes/pdoDB.class.php');
require_once('classes/ApplicationRegistry.class.php');
require_once('classes/JSONRecordSet.class.php');
require_once('classes/session.class.php');

//variables set from data from URl
$action = isset($_REQUEST['action']) ? $_REQUEST['action'] : null;
$subject = isset($_REQUEST['subject']) ? $_REQUEST['subject'] : null;
$id = isset($_REQUEST['id']) ? $_REQUEST['id'] : null;
$category = isset($_REQUEST['category']) ? $_REQUEST['category'] : null;
$term = isset($_REQUEST['term']) ? $_REQUEST['term'] : null;


if (empty($action)) {
    if ((($_SERVER['REQUEST_METHOD'] == 'POST') ||
            ($_SERVER['REQUEST_METHOD'] == 'PUT') ||
            ($_SERVER['REQUEST_METHOD'] == 'DELETE')) &&
        (strpos($_SERVER['CONTENT_TYPE'], 'application/json') !== false)) {

        $input = json_decode(file_get_contents('php://input'), true);

        $action = isset($input['action']) ? $input['action'] : null;
        $subject = isset($input['subject']) ? $input['subject'] : null;
        $data = isset($input['data']) ? $input['data'] : null;

    }
}

// concat action and subject with uppercase first letter of subject
$route = $action . ucfirst($subject); // eg list course becomes listCourse

$db = ApplicationRegistry::DB(); // connect to db

//set the header to json because everything is returned in that format
header("Content-Type: application/json");

//varabiles set for coding testing
$user = 'rob@sfilms.com';
$timestamp = '2019-04-15 17:21:41';
$session= $username= $passwordE ="";

// take the appropriate action based on the action and subject
switch ($route) {
    case 'someActionRequiringLogin' :

        if (!empty($session->user)) {
            // construct appropriate sql
            // execute using xml or json record set class
            // echo return value from record set
        }
        else {
            // this header could be type xml if that's required by your client-side app
            header("Content-Type: application/json", true, 412);  // 412 means 'precondition failed'
            echo '{"status":{"error":"error", "text":"login required to view this information"}}';
        }
        break;

    case 'loginUser':

        $session->removeKey('username');
        $session->removeKey('userid');

        $usr   = $username; // maybe from request stream or any data object
        $passw = $passwordE;
        if (!empty($usr) && !empty($passw)) { // if both username and password are present try and log in
            $rs       = "";  // it's easier to use an 'ordinary' record set

            // construct login sql using placeholders
            $loginSQL = "SELECT userid, username, email, password FROM srs_user WHERE userid=:userid";
            // create an array for the placeholder values -notice I encrypt the password, in this example using md5
            $params   = array(':userid' => $usr);

            // use getRecordSet -I've modified my version to allow an optional $params parameter which, if there is
            // on it'll use execute() instead of just query()
            $rs   = $rs->getRecordSet($loginSQL, 'ResultSet', $params);

            if ($rs !== false) {  // there is a record set
                $user = $rs->fetchObject();
                // check if the encrypted password matches the one supplied

            }
        }
        // login failed if here
        header("Content-Type: application/json", true, 401);  // 401 means 'authorisation failed failed'
        echo '{"status":{"error":"error", "text":"Login credentials incorrect"}}';
        break;

    case 'isloggedinUser':
        if (!empty($session->user)) {
            $user = $session->user;
            echo $user;
        }
        else {
            echo '{"status":{"error":"error", "text":"user not logged in"}}';
        }
        break;

    case 'logoutUser':
        if ($session->removeKey('user')) {
            echo '{"status":{"text":"user logged out"}}';
        }
        else {
            echo '{"status":{"error":"error", "text":"no user logged in"}}';
        }
        break;
    case 'listDetails':
        //  $id = $db->quote($id);
        $sqlFilmDetails = "SELECT c.name, e.length, e.rental_rate, e.special_features, e.title
                              FROM nfc_film e
                              JOIN nfc_language c
                              ON e.language_id = c.language_id
                              WHERE e.film_id = '$id'";
        $rs = new JSONRecordSet();
        $retval = $rs->getRecordSet($sqlFilmDetails, 'ResultSet');
        echo $retval;
        break;

    case 'listActors':
        //  $id = $db->quote($id);
        $sqlFilmActors = "SELECT c.actor_id, d.first_name, d.last_name
                              FROM nfc_film_actor c
                              JOIN nfc_actor d
                              ON c.actor_id = d.actor_id
                              WHERE c.film_id = '$id'
                              ORDER BY d.last_name";
        $rs = new JSONRecordSet();
        $retval = $rs->getRecordSet($sqlFilmActors, 'ResultSet');
        echo $retval;
        break;


    case 'listFilms':
        //  $id = $db->quote($id);
        $sqlListFilms = "SELECT c.film_id, title, release_year, rating, description, e.name, c.last_update
                              FROM nfc_film c
                              INNER JOIN nfc_film_category d
                              ON c.film_id=d.film_id
                              INNER JOIN nfc_category e
                              ON d.category_id=e.category_id
                              ORDER BY c.film_id
                            ";


        $sqlListCategory = "SELECT e.film_id, e.title, e.release_year, e.rating, e.description, d.name, e.last_update, d.category_id
                              FROM nfc_film_category c
                              JOIN nfc_category d
                              ON c.category_id = d.category_id
                              JOIN nfc_film e
                              ON e.film_id = c.film_id
                              WHERE c.category_id = '$category'
                              ORDER BY e.title";

        $sqlListTerm = "SELECT  e.film_id, e.title, e.release_year, e.rating, e.description, d.name, e.last_update, d.category_id
                              FROM nfc_film_category c
                              JOIN nfc_category d
                              ON c.category_id = d.category_id
                              JOIN nfc_film e
                              ON e.film_id = c.film_id
                              WHERE (e.title LIKE '%$term%'
                                       OR d.name LIKE '%$term%')
                             ORDER BY e.film_id";


        $rs = new JSONRecordSet();
        if (isset($category)) {
            $retval = $rs->getRecordSet($sqlListCategory, 'ResultSet');
            echo $retval;
            break;
        } else if (isset($term)) {
            $retval = $rs->getRecordSet($sqlListTerm, 'ResultSet');
            echo $retval;
            break;
        } else {
            $retval = $rs->getRecordSet($sqlListFilms, 'ResultSet');
            echo $retval;
        }
        break;

    case 'listGenre':
        $sqlListGenre = "SELECT c.name
                        FROM nfc_category c
                        ORDER BY c.name";
        $rs = new JSONRecordSet();
        $retval = $rs->getRecordSet($sqlListGenre, 'ResultSet');
        echo $retval;
        break;


    case 'listNotes':
        //  $id = $db->quote($id);
        $sqlListNotes = "SELECT c.user, film_id, comment, lastupdated, d.username
                        FROM nfc_note c
                         JOIN nfc_user d
                          ON user = d.email
                          where film_id ='$id'";
        $rs = new JSONRecordSet();
        $retval = $rs->getRecordSet($sqlListNotes, 'ResultSet');
        echo $retval;
        break;

        //case for updating a note
    case 'updateNote':
        if (!empty($data)) {
            $note = json_decode($data);
            $noteUpdateSQL = "update nfc_note 
                                  set comment=:comment, film_id=:film_id
                                  where film_id='$id'";
            $rs = new JSONRecordSet();
            $retval = $rs->getRecordSet($noteUpdateSQL, 'ResultSet',
                array(':comment' => $note->comment,   ':film_id'=>$note->film_id
                ));
            echo '{"status":"ok", "message":{"text":"updated", "film_id":"' . $note->film_id . '"}}';
        }
        break;

        //Case for new notes
    case 'newNote':
        if (!empty($data)) {
            $newNote = json_decode($data);
            $newNoteSQL = "INSERT INTO nfc_note c (c.user, comment, film_id, lastupdated)
                                  VALUES (user=:user, comment=:comment, film_id=:film_id, lastupdated=:lastupdated);";
            $rs = new JSONRecordSet();
            $retval = $rs->getRecordSet($newNoteSQL, 'ResultSet',
                array(':user' => $user, ':comment' => $newNote->comment, ':film_id' => $newNote->film_id,
                     ':lastupdated' => $newNote->$timestamp
                ));
            echo '{"status":"ok", "message":{"text":"updated", "film_id":"' . $newNote->film_id . '"}}';
        }
        break;


    default:
        echo '{"status":"error", "message":{"text": "default no action taken"}}';
        break;

}
?>