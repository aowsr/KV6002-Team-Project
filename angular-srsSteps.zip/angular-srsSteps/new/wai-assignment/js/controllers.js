(function () {
    "use strict";

    /**
     * Extend the module 'CourseApp' instantiated in app.js  To add a controller called
     * IndexController (on line 17) and CourseController (on line 26)
     *
     * The controller is given two parameters, a name as a string and an array.
     * The array lists any injected objects to add and then a function which will be the
     * controller object and can contain properties and methods.
     * $scope is a built in object which refers to the application model and acts
     * as a sort of link between the controller, its data and the application views.
     *
     * @link https://docs.angularjs.org/guide/scope
     */
    angular.module('FilmApp').controller('IndexController',   // controller given two params, a name and an array
        [
            function () {
                this.title = 'All Films';
                this.subtitle = 'Film Details';
            }
        ]
    ).filter('searchFor', function(){

        // All filters must return a function. The first parameter
        // is the data that is to be filtered, and the second is an
        // argument that may be passed with a colon (searchFor:searchString)

        return function(arr, searchString){

            if(!searchString){
                return arr;
            }

            var result = [];

            searchString = searchString.toLowerCase();

            // Using the forEach helper method to loop through the array
            angular.forEach(arr, function(item){

                if(item.title.toLowerCase().indexOf(searchString) !== -1){
                    result.push(item);
                }

            });

            return result;
        };

    }).controller('FilmController',  // create a CourseController
        [
            '$scope',
            'dataService',
            '$location',
            function ($scope, dataService, $location) {


                var getFilms = function () {
                    $scope.films = [];
                    $scope.filmCount = 0;
                    $scope.genres = [];
                    $scope.genreCount = 0;
                    // call the dataService method which uses ajax to retrieve courses
                    dataService.getFilms().then(  // then() is called when the promise is resolve or rejected
                        function (response) {
                            $scope.filmCount = response.rowCount + ' films';
                            $scope.films = response.data;

                        },
                        function (err) {
                            $scope.status = 'Unable to load data ' + err;
                        },
                        function (notify) {
                            console.log(notify);
                        }
                    ); // end of getCourses().then
                };
                var filmInfo = $location.path().substr(1).split('/');

                if (filmInfo.length === 2) {
                    // use the course code from the path and assign to
                    // selectedCourse so if the page is reloaded it's highlighted
                    $scope.selectedFilm = {film_id: filmInfo[1]};
                }

                $scope.selectedFilm = {};

                $scope.selectFilm = function ($event, film) {
                    $scope.selectedFilm = film;
                    $location.path('/films/' + film.film_id);
                };


                var getGenre = function () {
                    dataService.getGenre().then(
                        function (response) {
                            $scope.genreCount = response.rowCount + ' genres';
                            $scope.genres = response.data;
                        },
                        function (err) {
                            $scope.status = 'Unable to load data ' + err;
                        }
                    );  // end of getStudents().then
                };


                $scope.termEnter = function (term) {
                    $scope.term = term;
                    $location.path('/' + $scope.term);
                    console.log(term);
                };



                // everything is ready so now load the courses by calling the local function getCourses()
                getFilms();
                getGenre();




                $scope.sort = function (keyname) {
                    $scope.sortKey = keyname;   //set the sortKey to the param passed
                    $scope.reverse = !$scope.reverse; //if true make it false and vice versa
                };

            }
        ]
    ).controller('login_register_controller', function($scope, $http){
        $scope.closeMsg = function(){
            $scope.alertMsg = false;
        };

        $scope.login_form = true;


        $scope.showLogin = function(){
            $scope.register_form = false;
            $scope.login_form = true;
            $scope.alertMsg = false;
        };


        $scope.submitLogin = function(){
            $http({
                method:"POST",
                url:"login.php",
                data:$scope.loginData
            }).success(function(data){
                if(data.error != '')
                {
                    $scope.alertMsg = true;
                    $scope.alertClass = 'alert-danger';
                    $scope.alertMessage = data.error;
                }
                else
                {
                    location.reload();
                }
            });
        }}).controller('FilmActorsController',
        [
            '$scope',
            'dataService',
            '$routeParams',
            '$location',

            function ($scope, dataService, $routeParams, $location) {
                $scope.actors = [];
                $scope.actorCount = 0;
                $scope.details = [];
                $scope.detailsCount = 0;
                $scope.notes = [];
                $scope.noteCount = 0;


                var getActors = function (film_id) {
                    dataService.getActors(film_id).then(
                        function (response) {
                            $scope.actorCount = response.rowCount + ' actors';
                            $scope.actors = response.data;
                        },
                        function (err) {
                            $scope.status = 'Unable to load data ' + err;
                        }
                    );  // end of getStudents().then
                };

                var getDetails = function (film_id) {
                    dataService.getDetails(film_id).then(
                        function (response) {
                            $scope.detailsCount = response.rowCount + ' details';
                            $scope.details = response.data;
                        },
                        function (err) {
                            $scope.status = 'Unable to load data ' + err;
                        }
                    );  // end of getStudents().then
                };

                var getNotes = function (film_id) {
                    dataService.getNotes(film_id).then(
                        function (response) {
                            $scope.noteCount = response.rowCount + ' notes';
                            $scope.notes = response.data;
                        },
                        function (err) {
                            $scope.status = 'Unable to load data ' + err;
                        }
                    );  // end of getStudents().then
                };

                getNotes();
                getDetails();
                getActors();

                // only if there has been a courseid passed in do we bother trying to get the students
                if ($routeParams && $routeParams.film_id) {
                    console.log($routeParams.film_id);
                    getActors($routeParams.film_id);
                    getDetails($routeParams.film_id);
                    getNotes($routeParams.film_id);
                }


                $scope.showEditNote = function (film_id) {

                    console.log(film_id);
                    $scope.selectedNote = angular.copy(film_id);
                    $scope.editorVisible = true;

                };

                $scope.newNote = function () {
                    $scope.editorVisible2 = true;

                };

                $scope.abandonEdit = function () {
                    $scope.editorVisible = false;
                    $scope.selectedNote = null;
                    $scope.editorVisible2 = false;
                };


                $scope.saveNote = function () {
                    var n,
                        scount = $scope.notes.length,
                        currentNote;

                    $scope.editorVisible = false;
                    // call dataService method
                    dataService.updateNote($scope.selectedNote).then(
                        function (response) {
                            $scope.status = response.status;
                            if (response.status === 'ok') { // if we saved the file then update the screen
                                for (n = 0; n < scount; n += 1) {
                                    currentNote = $scope.notes[n];
                                    if (currentNote.film_id === $scope.selectedNote.film_id) {
                                        $scope.notes[n] = angular.copy($scope.selectedNote);
                                        break;
                                    }
                                }
                            }
                            console.log(response);
                            // reset selectedStudent
                            $scope.selectedNote = null;
                        },
                        function (err) {
                            $scope.status = "Error with save " + err;
                        }
                    );
                };

                $scope.saveNewNote = function () {
                    var n,
                        scount = $scope.notes.length,
                        currentNote;

                    $scope.editorVisible2 = false;
                    // call dataService method
                    dataService.newNote($scope.newNote).then(
                        function (response) {
                            $scope.status = response.status;
                            if (response.status === 'ok') { // if we saved the file then update the screen
                                for (n = 0; n < scount; n += 1) {
                                    currentNote = $scope.notes[n];
                                    if (currentNote.film_id === $scope.newNote.film_id) {
                                        $scope.notes[n] = angular.copy($scope.newNote);
                                        break;
                                    }
                                }
                            }
                            console.log(response);
                            // reset selectedStudent
                            $scope.newNote = null;
                        },
                        function (err) {
                            $scope.status = "Error with save " + err;
                        }
                    );
                }

            }
        ]
    ).controller('TermController',
        [
            '$scope',
            'dataService',
            '$routeParams',
            '$location',

            function ($scope, dataService, $routeParams, $location) {
                $scope.terms = [];
                $scope.termCount = 0;


                var getTerm = function (term) {
                    dataService.getTerm(term).then(
                        function (response) {
                            $scope.termCount = response.rowCount + ' Results';
                            $scope.terms = response.data;
                        },
                        function (err) {
                            $scope.status = 'Unable to load data ' + err;
                        }
                    );  // end of getStudents().then
                };


                // only if there has been a courseid passed in do we bother trying to get the students
                if ($routeParams && $routeParams.term) {
                    console.log($routeParams.term);
                    getTerm($routeParams.term);
                }


            }


        ]
    ).controller('CategoryController',
        [
            '$scope',
            'dataService',
            '$routeParams',
            '$location',

            function ($scope, dataService, $routeParams, $location) {
                $scope.categorys = [];
                $scope.categoryCount = 0;


                var getCategory = function (category_id) {
                    dataService.getCategory(category_id).then(
                        function (response) {
                            $scope.categoryCount = response.rowCount + ' categorys';
                            $scope.categorys = response.data;
                        },
                        function (err) {
                            $scope.status = 'Unable to load data ' + err;
                        }
                    );  // end of getStudents().then
                };



                // only if there has been a courseid passed in do we bother trying to get the students
                if ($routeParams && $routeParams.category_id) {
                    console.log($routeParams.category_id);
                    getCategory($routeParams.category_id);
                }


            }


        ]
    )
}());