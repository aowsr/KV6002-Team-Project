
Only functionalities not fully achieved within this assignment was the login system. 

This was attempted but was not fully functioning, due to this the notes were implemented but are not able to create new notes as user credentials were required for this within the sql statement for successful new note.

The application does not load the traversed json data onto the localhost when using XAMPP. Alternative link has been provided for the API which is hosted on newnumyspace. 
This was advised as the problem did not arise using newnumyspace also having the test page working indicated the php server side was working correctly.

http://unn-w16028251.newnumyspace.co.uk/wai-assignment/#/