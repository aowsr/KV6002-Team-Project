(function () {
    "use strict";

    /**
     * Start a new Application, a module in Angular
     * @param {string} ApplicationName a string which will be the name of the application
     *                 and, in fact, an object to which we add all other components
     */
    angular.module("PHPAssignment", [
        "ngRoute"
    ])
        .config([
            "$routeProvider",
            function ($routeProvider) {
                $routeProvider.
                    when("/countries", {
                        templateUrl: "js/partials/country-list.html"
                    })
                    .otherwise({
                        redirectTo: "/"
                    });
            }
        ]);
})();