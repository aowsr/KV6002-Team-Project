(function () {
    "use strict";
    angular.module("PHPAssignment").service(
        "dataService",
        [
            "$q",
            "$http",
            function ($q, $http) {
                var urlBase = "/wai-assigment/server/index.php";

                this.getCountryData = function (country_id) {
                    var defer = $q.defer(),
                        data = {
                            action: "list",
                            subject: "country",
                            id: country_id
                        };

                    $http
                        .get(urlBase, { params: data })
                        .success(function (response) {
                            defer.resolve({
                                data: {
                                    country: response.ResultSet.Result[0],
                                    Continent: response.ResultSet.Continent,
                                    note: response.ResultSet.note[0]
                                }
                            });
                        })
                        .error(function (error) {
                            defer.reject(error);
                        });



                    return defer.promise;
                };

                /**
                 * A method to create a note
                 * @param {object} data
                 */
                this.createNote = function (data) {
                    var defer = $q.defer(),
                        data = {
                            action: "create",
                            subject: "note",
                            data: angular.toJson(data)
                        };

                    $http
                        .post(urlBase, data)
                        .success(function (response) {
                            defer.resolve({
                                data: response.data
                            });
                        })
                        .error(function (error) {
                            defer.reject(error);
                        });



                    return defer.promise;
                };

                /**
                 * A method to update a note
                 * @param {object} data
                 */
                this.updateNote = function (data) {
                    var defer = $q.defer(),
                        data = {
                            action: "update",
                            subject: "note",
                            data: angular.toJson(data)
                        };

                    $http
                        .post(urlBase, data)
                        .success(function (response) {
                            console.log(response);
                            defer.resolve({
                                data: response.data
                            });
                        })
                        .error(function (error) {
                            defer.reject(error);
                        });



                    return defer.promise;
                };

                /**
                 * A method to retrieve countries by term
                 * @param {string} term
                 */
                this.getcountrysByTerm = function (term) {
                    var defer = $q.defer(),
                        data = {
                            action: "list",
                            subject: "countries",
                            term: term
                        };

                    $http
                        .get(urlBase, { params: data, cache: true })
                        .success(function (response) {
                            defer.resolve({
                                data: response.data.Result
                            });
                        })
                        .error(function (error) {
                            defer.reject(error);
                        });



                    return defer.promise;
                };

                /**
                 * A method to retrieve retrieve all countries
                 */
                this.getcountrys = function () {
                    var defer = $q.defer(),
                        data = {
                            action: "list",
                            subject: "countries"
                        };
                    $http
                        .get(urlBase, { params: data, cache: true })
                        .success(function (response) {
                            defer.resolve({
                                data: response.data.Result,
                                categories: response.data.Categories.Result
                            });
                        })
                        .error(function (error) {
                            defer.reject(error);
                        });



                    return defer.promise;
                };

                /**
                 * A method to retrieve all countries by category
                 * @param {integer} category_id
                 */
                this.getcountrysByCategory = function (category_id) {
                    var defer = $q.defer(),
                        data = {
                            action: "list",
                            subject: "countries",
                            category: category_id
                        };

                    $http
                        .get(urlBase, { params: data, cache: false })
                        .success(function (response) {
                            defer.resolve({
                                data: response.ResultSet.Result
                            });
                        })
                        .error(function (error) {
                            defer.reject(error);
                        });



                    return defer.promise;
                };

                /**
                 * A method to login a user and perform post request
                 * @param {object} data
                 */
                this.loginUser = function (data) {
                    var defer = $q.defer(),
                        data = {
                            action: "login",
                            subject: "user",
                            data: angular.toJson(data)
                        };

                    $http
                        .post(urlBase, data)
                        .success(function (response) {
                            defer.resolve({
                                data: response.Result,
                                status: response.status
                            });
                        })
                        .error(function (error) {
                            defer.reject(error);
                        });



                    return defer.promise;
                };

                /**
                 * A method to logout a user
                 */
                this.logout = function () {
                    var defer = $q.defer(),
                        data = {
                            action: "logout",
                            subject: "user"
                        };

                    $http
                        .post(urlBase, data)
                        .success(function (response) {
                            defer.resolve({
                                status: response.status
                            });
                        })
                        .error(function (error) {
                            defer.reject(error);
                        });



                    return defer.promise;
                };

                /**
                 * A method to check for session
                 */
                this.checkSession = function () {
                    var defer = $q.defer(),
                        data = {
                            action: "isLoggedIn"
                        };

                    $http
                        .get(urlBase, { params: data })
                        .success(function (response) {
                            defer.resolve({
                                data: response
                            })
                        })
                        .error(function (error) {
                            defer.reject(error);
                        });



                    return defer.promise;
                };
            }
        ]
    );
})();
