(function () {
    "use strict";

    angular
        .module("PHPAssignment")
        .controller(
            "IndexController",
            [
                "$scope",
                "dataService",

                function ($scope, dataService) {
                    $scope.session = {
                        email: null,
                        username: null
                    };

                    $scope.checkSession = function () {
                        dataService.checkSession().then(
                            function (response) {
                                if (response.data.status === 200) {
                                    $scope.session = {
                                        email: response.data.user.email,
                                        username: response.data.user.username
                                    };
                                } else {
                                    $scope.session = {};
                                }
                            },
                            function (error) {
                                $scope.status = "Unable to load data " + error;
                            }
                        );
                    };

                    $scope.checkSession();
                }
            ]
        )
        .controller("AuthenticationController", [
            "$scope",
            "dataService",

            function ($scope, dataService) {

                $scope.loginUser = function (_username, _password) {

                    var data = {
                        username: _username,
                        password: _password
                    };
                    dataService.loginUser(data).then(
                        function (response) {
                            $scope.session.email = response.data.email;
                            $scope.session.username = response.data.username;
                        },
                        function (error) {
                            $scope.status = "Unable to load data " + error;
                        }
                    );
                };
                $scope.logout = function () {
                    dataService.logout().then(
                        function (response) {
                            if (response.status === 200) {
                                $scope.checkSession();
                            }
                        },
                        function (error) {
                            $scope.status = "Unable to load data " + error;
                        }
                    );
                };
            }
        ])
        .controller("NotesController", [
            "$scope",
            "dataService",

            function ($scope, dataService) {

                $scope.isUpdating = false;

                $scope.createNote = function (note) {

                    var data = [
                        $scope.session.email,
                        note,
                        $scope.selectedcountryData.country_id
                    ];

                    dataService.createNote(data).then(
                        function (response) {
                            $scope.selectcountry(
                                null,
                                $scope.selectedcountryData.country_id
                            );
                        },
                        function (error) {
                            $scope.status = "Unable to load data " + error;
                        }
                    );
                };

                $scope.updateNote = function (note) {

                    var data = [
                        $scope.session.email,
                        note,
                        $scope.selectedcountryData.country_id
                    ];

                    dataService.updateNote(data).then(
                        function (response) {
                            $scope.isUpdating = false;
                            $scope.selectcountry(
                                null,
                                $scope.selectedcountryData.country_id
                            );
                        },
                        function (error) {
                            $scope.status = "Unable to load data " + error;
                        }
                    );
                };
                $scope.allowUpdate = function () {
                    $scope.isUpdating = !$scope.IsUpdating;
                };
            }
        ])
        .controller("countrysController", [
            "$scope",
            "dataService",
            "$routeParams",

            function ($scope, dataService, $routeParams) {

                $scope.continent = [];
                $scope.country = [];

                var getcountrys = function () {
                    dataService.getcountrys().then(
                        function (response) {
                            $scope.continent = response.data;
                            $scope.country = response.categories;
                        },
                        function (error) {
                            $scope.status = "Unable to load data " + error;
                        }
                    );
                };

                var getcountrysByCategory = function (category_id) {
                    dataService.getcountrysByCategory(category_id).then(
                        function (response) {
                            if (response.data == []) {
                                $scope.movies = [];
                            } else {
                                $scope.movies = response.data;
                            }
                        },
                        function (error) {
                            $scope.status = "Unable to load data " + error;
                        }
                    );
                };

                $scope.filterTerm = "";
                $scope.filterCountries = function (phrase) {
                    dataService.getcountrysByTerm(phrase).then(
                        function (response) {
                            $scope.movies = response.data;
                        },
                        function (error) {
                            $scope.status = "Unable to load data " + error;
                        }
                    );
                };
                $scope.selectedCategory = {};
                $scope.selectCategory = function () {
                    $scope.selectedCategory = $scope.selectedCategory;
                    getcountrysByCategory($scope.selectedCategory.category_id);
                };
                $scope.selectedcountryData = {};
                $scope.selectedcountryContinent = {};
                $scope.selectcountry = function ($event, country_id) {
                    dataService.getCountryData(country_id).then(
                        function (response) {
                            $scope.selectedcountryData = response.data.country;
                            $scope.selectedcountryContinent = response.data.Continent;
                            $scope.selectedcountryNote = response.data.note;
                        },
                        function (error) {
                            $scope.status = "Unable to load data " + error;
                        }
                    );
                };

                if ($routeParams && $routeParams.category_id) {
                    getcountrysByCategory($routeParams.category_id);
                }

                getcountrys();
            }
        ]);
})();
