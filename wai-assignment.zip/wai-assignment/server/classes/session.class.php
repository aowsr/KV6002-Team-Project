<?php


Class Session{
    private static $username;
    private function __construct(){
        session_start();
    }
    public static function getInstance() {
        if (!isset(self::$username)) {
            self::$username = new Session();
        }
        return self::$username;
    }
    public function setProperty( $key, $val ) {
        /* don't need to check that session exists
        since if we're here we must have instantiated
        $instance and started the session */
        $_SESSION[ $key ] = $val;
    }
    public function getProperty( $key ) {
        $returnValue = "";
        if (isset($_SESSION[$key])) {
            $returnValue = $_SESSION[$key];
        }
        return $returnValue;
    }
}


