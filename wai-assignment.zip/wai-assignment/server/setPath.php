<?php
ini_set("session.save_path", "/home/unn_w16014111/sessionData");
session_start();
?>