<?php
require_once('classes/webpage.class.php');
require_once('errorFunctions.php');
require_once('setEnv.php');
require_once('setPath.php');
require_once('classes/pdoDB.class.php');
require_once('classes/ApplicationRegistry.class.php');
require_once('classes/JSONRecordSet.class.php');
require_once('classes/session.class.php');

//variables set from data from URl
$action = isset($_REQUEST['action']) ? $_REQUEST['action'] : null;
$subject = isset($_REQUEST['subject']) ? $_REQUEST['subject'] : null;
$id = isset($_REQUEST['id']) ? $_REQUEST['id'] : null;


if (empty($action)) {
    if ((($_SERVER['REQUEST_METHOD'] == 'POST') ||
            ($_SERVER['REQUEST_METHOD'] == 'PUT') ||
            ($_SERVER['REQUEST_METHOD'] == 'DELETE')) &&
        (strpos($_SERVER['CONTENT_TYPE'], 'application/json') !== false)) {

        $input = json_decode(file_get_contents('php://input'), true);

        $action = isset($input['action']) ? $input['action'] : null;
        $subject = isset($input['subject']) ? $input['subject'] : null;
        $data = isset($input['data']) ? $input['data'] : null;

    }
}

// concat action and subject with uppercase first letter of subject
$route = $action . ucfirst($subject); // eg list course becomes listCourse

$db = ApplicationRegistry::DB(); // connect to db

//set the header to json because everything is returned in that format
header("Content-Type: application/json");


// take the appropriate action based on the action and subject
switch ($route) {

    case 'showContinents':
        //  $id = $db->quote($id);
        $sqlContinents = "SELECT w_continent.name 
                                  FROM w_continent 
                                  ORDER BY w_continent.ID";
        $rs = new JSONRecordSet();
        $retval = $rs->getRecordSet($sqlContinents, 'ResultSet');
        echo $retval;
        break;

    case 'showCountriesOnContinent':
        //  $id = $db->quote($id);
        $sqlCountries = "SELECT w_continent.id, w_continent.name, w_country.A3Code, w_country.name,
                                     w_country.population, w_country.capital
                           FROM w_continent
                           JOIN w_country
                           ON w_continent.id = w_country.continent
                           ORDER by w_continent.name";
        $rs = new JSONRecordSet();
        $retval = $rs->getRecordSet($sqlCountries, 'ResultSet');
        echo $retval;
        break;

    case 'search':
        $sqlSearch = "SELECT w_continent.id, w_continent.name, w_country.A3Code, w_country.name,
                                     w_country.population, w_country.capital
                           FROM w_continent
                           JOIN w_country
                           ON w_continent.id = w_country.continent";
        $rs = new JSONRecordSet();
        $retval = $rs->getRecordSet($sqlSearch, 'ResultSet');
        echo $retval;
        break;

    case 'showCountryInfo':
        $sqlCountryInfo = "SELECT w_continent.id, w_continent.name, w_country.A3Code, w_country.name,
                                     w_country.population, w_country.capital
                           FROM w_continent
                           JOIN w_country
                           ON w_continent.id = w_country.continent";
        $rs = new JSONRecordSet();
        $retval = $rs->getRecordSet($sqlCountryInfo, 'ResultSet');
        echo $retval;
        break;

    case 'changeHofS':
        //  $id = $db->quote($id);
        $sqlHead = "SELECT w_country.HeadOfState 
                                  FROM w_country";
        $rs = new JSONRecordSet();
        $retval = $rs->getRecordSet($sqlHead, 'ResultSet');
        echo $retval;
        break;


    default:
        echo '{"status":"error", "message":{"text": "default no action taken"}}';
        break;

}
?>